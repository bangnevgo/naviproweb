'use client';

import Link from 'next/link';
import { useState } from 'react';

export default function DemoPage() {
  return (
    <main className="min-h-screen bg-gray-950 text-white flex flex-col items-center justify-center p-8">
      <div className="text-center">
        <h1 className="text-4xl font-bold mb-6">
          NAVI Pro Interactive Demo
        </h1>
        <p className="text-lg text-gray-300 mb-8">
          Jelajahi bagaimana platform AI kami bekerja untuk meningkatkan lead generation toko Anda
        </p>
        <Link
          href="/"
          className="bg-indigo-600 hover:bg-indigo-500 text-white font-medium px-8 py-3 rounded-lg transition-all hover:shadow-lg hover:shadow-indigo-500/25"
        >
          Kembali ke Beranda & Mulai Trial Gratis
        </Link>
      </div>
    </main>
  );
}