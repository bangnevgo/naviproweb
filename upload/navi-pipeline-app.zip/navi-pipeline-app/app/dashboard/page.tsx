import Link from 'next/link';
import AnalyticsCards from '@/components/AnalyticsCards';
import PipelineFlow from '@/components/PipelineFlow';
import LeadTable from '@/components/LeadTable';
import LiveFeed from '@/components/LiveFeed';
import { defaultLeads } from '@/lib/demo-data';

export default function Dashboard() {
  const leads = defaultLeads;

  return (
    <div className="min-h-screen bg-gray-950 text-white">
      {/* Top Nav */}
      <header className="sticky top-0 z-50 bg-gray-950/80 backdrop-blur-md border-b border-gray-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-14">
            <div className="flex items-center gap-3">
              <Link href="/" className="flex items-center gap-2">
                <div className="w-7 h-7 rounded-md bg-gradient-to-br from-indigo-500 to-cyan-400 flex items-center justify-center text-[10px] font-bold">N</div>
                <span className="font-bold">NAVI Pro</span>
              </Link>
              <span className="hidden sm:inline text-[10px] text-gray-500 border border-gray-700 rounded px-2 py-0.5">Demo</span>
            </div>
            <div className="flex items-center gap-3">
              <span className="flex items-center gap-1.5 text-xs text-emerald-400">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                All Systems Live
              </span>
              <Link href="/" className="text-xs text-gray-500 hover:text-gray-300 transition-colors">Home</Link>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
        {/* Welcome */}
        <div>
          <h1 className="text-xl font-bold">Dashboard Demo</h1>
          <p className="text-sm text-gray-400">ini adalah simulasi live 6-agent AI pipeline. Data di-refresh secara real-time.</p>
        </div>

        {/* Analytics */}
        <AnalyticsCards />

        {/* Pipeline + Live Feed */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2">
            <PipelineFlow />
          </div>
          <div>
            <LiveFeed />
          </div>
        </div>

        {/* Leads Table */}
        <div className="bg-gray-800/60 backdrop-blur rounded-xl border border-gray-700 p-5">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-semibold text-gray-300 uppercase tracking-wider">Lead Pipeline</h3>
              <p className="text-xs text-gray-500 mt-0.5">{leads.length} leads aktif dalam pipeline</p>
            </div>
            <div className="flex gap-2 text-xs">
              <span className="bg-blue-500/10 text-blue-300 px-2 py-1 rounded">New: {leads.filter(l => l.status === 'new').length}</span>
              <span className="bg-emerald-500/10 text-emerald-300 px-2 py-1 rounded">Demo: {leads.filter(l => l.status === 'demo').length}</span>
              <span className="bg-amber-500/10 text-amber-300 px-2 py-1 rounded">Converted: {leads.filter(l => l.status === 'converted').length}</span>
            </div>
          </div>
          <LeadTable leads={leads} />
        </div>
      </main>
    </div>
  );
}
