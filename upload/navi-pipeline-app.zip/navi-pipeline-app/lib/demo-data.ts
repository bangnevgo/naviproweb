export interface Lead {
  id: string;
  name: string;
  store: string;
  platform: string;
  category: string;
  score: number;
  gmv: string;
  orders: number;
  status: 'new' | 'scored' | 'messaged' | 'demo' | 'converted';
  updatedAt: string;
}

export interface PipelineAgent {
  id: string;
  name: string;
  icon: string;
  description: string;
  status: 'active' | 'idle' | 'processing';
  processed: number;
  rate: string;
}

export type LeadStatus = Lead['status'];

const STORES = [
  { name: 'FashionGalaxy_ID', platform: 'Shopee', category: 'Fashion' },
  { name: 'ElektroMart88', platform: 'Tokopedia', category: 'Electronics' },
  { name: 'BeautyGlow_ID', platform: 'TikTok Shop', category: 'Beauty' },
  { name: 'RumahKeren_ID', platform: 'Shopee', category: 'Home & Living' },
  { name: 'GadgetPro_Store', platform: 'Tokopedia', category: 'Electronics' },
  { name: 'SkincareByAya', platform: 'Instagram', category: 'Beauty' },
  { name: 'BatikNusantara_ID', platform: 'Shopee', category: 'Fashion' },
  { name: 'KitchenAja_ID', platform: 'Tokopedia', category: 'Home & Living' },
  { name: 'SportyGear88', platform: 'TikTok Shop', category: 'Sports' },
  { name: 'MuslimahStyle_ID', platform: 'Instagram', category: 'Fashion' },
  { name: 'ToyBox_ID', platform: 'Shopee', category: 'Toys & Hobbies' },
  { name: 'HealthyLife_ID', platform: 'Tokopedia', category: 'Health' },
  { name: 'WatchesLux_ID', platform: 'Instagram', category: 'Accessories' },
  { name: 'PetLovers_ID', platform: 'Shopee', category: 'Pets' },
  { name: 'BukuKita_ID', platform: 'Tokopedia', category: 'Books' },
  { name: 'FurnitureIndah', platform: 'Shopee', category: 'Home & Living' },
  { name: 'JerseyTimnas_ID', platform: 'TikTok Shop', category: 'Sports' },
  { name: 'MakeupByDinda', platform: 'Instagram', category: 'Beauty' },
  { name: 'SepatuKeren_ID', platform: 'Tokopedia', category: 'Fashion' },
  { name: 'GamingGear_ID', platform: 'Shopee', category: 'Electronics' },
  { name: 'SnackMarket_ID', platform: 'TikTok Shop', category: 'Food' },
  { name: 'Handicraft_ID', platform: 'Instagram', category: 'Handicraft' },
  { name: 'PerabotRumah_ID', platform: 'Shopee', category: 'Home & Living' },
  { name: 'Aksesoris_ID', platform: 'Tokopedia', category: 'Accessories' },
  { name: 'HerbalStore_ID', platform: 'Instagram', category: 'Health' },
];

const CATEGORIES = [
  'Fashion', 'Electronics', 'Beauty', 'Home & Living', 'Sports',
  'Health', 'Accessories', 'Food', 'Books', 'Toys & Hobbies',
];

function randomInt(min: number, max: number) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

function randomPick<T>(arr: T[]): T {
  return arr[randomInt(0, arr.length - 1)];
}

function randomGMV(): string {
  const values = ['2.5jt', '3.8jt', '5.2jt', '7.1jt', '10.5jt', '15jt', '22jt', '30jt', '45jt', '60jt', '85jt', '120jt'];
  return randomPick(values);
}

function randomDate(): string {
  const days = randomInt(0, 30);
  const d = new Date();
  d.setDate(d.getDate() - days);
  return d.toISOString();
}

const FIRST_NAMES = ['Rina', 'Budi', 'Dewi', 'Andi', 'Sari', 'Agus', 'Maya', 'Rudi', 'Nina', 'Dedi', 'Indah', 'Tono', 'Wati', 'Hendra', 'Lina', 'Eko', 'Fitri', 'Yoga', 'Tari', 'Rizky'];

function randomName(): string {
  return randomPick(FIRST_NAMES);
}

export function generateLeads(count: number = 25): Lead[] {
  const statuses: LeadStatus[] = ['new', 'scored', 'messaged', 'demo', 'converted'];
  return Array.from({ length: count }, (_, i) => {
    const store = STORES[i % STORES.length];
    const score = randomInt(40, 99);
    let status: LeadStatus;
    if (score >= 85) status = 'converted';
    else if (score >= 75) status = 'demo';
    else if (score >= 60) status = 'messaged';
    else if (score >= 45) status = 'scored';
    else status = 'new';

    return {
      id: `lead-${i + 1}`,
      name: randomName(),
      store: store.name,
      platform: store.platform,
      category: store.category,
      score,
      gmv: randomGMV(),
      orders: randomInt(50, 5000),
      status,
      updatedAt: randomDate(),
    };
  });
}

export const defaultLeads: Lead[] = generateLeads(25);

export const pipelineAgents: PipelineAgent[] = [
  { id: 'scraper', name: 'Data Scraper', icon: '🔍', description: 'Koleksi data dari marketplace', status: 'active', processed: 2847, rate: '±12/dtik' },
  { id: 'enricher', name: 'Data Enricher', icon: '📊', description: 'Enrichment dengan AI insight', status: 'active', processed: 2541, rate: '±10/dtik' },
  { id: 'scorer', name: 'AI Scorer', icon: '🎯', description: 'Scoring 100 parameter ML', status: 'active', processed: 2234, rate: '±8/dtik' },
  { id: 'generator', name: 'URL Generator', icon: '🔗', description: 'Generate tracking pages', status: 'idle', processed: 1890, rate: '±6/dtik' },
  { id: 'composer', name: 'Message Composer', icon: '✉️', description: 'Personalized AI messages', status: 'processing', processed: 1547, rate: '±5/dtik' },
  { id: 'sender', name: 'Multi-Channel DM', icon: '📨', description: 'Kirim ke semua platform', status: 'active', processed: 847, rate: '±3/dtik' },
];

export interface LiveEvent {
  id: number;
  type: 'lead' | 'score' | 'message' | 'demo' | 'conversion';
  message: string;
  time: string;
}

export function generateLiveFeed(count: number = 15): LiveEvent[] {
  const events = [
    { type: 'lead', message: '🛍️ Lead baru dari Tokopedia — Toko BatikNusantara' },
    { type: 'score', message: '🎯 Skor 92/100 — FashionGalaxy_ID masuk High Priority' },
    { type: 'message', message: '✉️ DM terkirim ke ElektroMart88 via Shopee Chat' },
    { type: 'demo', message: '📅 Demo dijadwalkan — BeautyGlow_ID, besok 10:00' },
    { type: 'conversion', message: '✅ Konversi! GadgetPro_Store upgrade ke Growth Plan' },
    { type: 'lead', message: '🛍️ Lead baru dari Instagram — SkincareByAya' },
    { type: 'score', message: '🎯 Skor 78/100 — RumahKeren_ID masuk Medium Priority' },
    { type: 'message', message: '✉️ DM Broadcast terkirim ke 47 leads Fashion' },
    { type: 'lead', message: '🛍️ Lead baru dari TikTok Shop — SportyGear88' },
    { type: 'score', message: '🎯 Skor 95/100 — MuslimahStyle_ID Top Scorer hari ini' },
    { type: 'message', message: '✉️ Follow-up otomatis ke WatchesLux_ID via Instagram DM' },
    { type: 'demo', message: '📅 Demo request — PetLovers_ID, Jumat 14:00' },
    { type: 'conversion', message: '✅ Konversi! BukuKita_ID activate Growth Plan' },
    { type: 'lead', message: '🛍️ Lead baru dari Shopee — FurnitureIndah' },
    { type: 'score', message: '🎯 Skor 88/100 — MakeupByDinda masuk High Priority' },
  ];
  return events.slice(0, count).map((e, i) => ({
    ...e,
    id: i + 1,
    time: `${randomInt(8, 17)}:${String(randomInt(0, 59)).padStart(2, '0')}`,
  })) as LiveEvent[];
}

export const platformStats = {
  totalLeads: 1234,
  todayLeads: 47,
  replyRate: 78,
  avgScore: 78.4,
  demoBooked: 234,
  conversionRate: 32,
  activeUsers: 128,
  totalSent: 8472,
  gmvImpact: '12.8M',
  topPlatform: 'Shopee',
};
