'use client';

import { pipelineAgents, type PipelineAgent } from '@/lib/demo-data';

const statusColors: Record<PipelineAgent['status'], string> = {
  active: 'bg-emerald-500 shadow-[0_0_12px_rgba(16,185,129,0.5)]',
  processing: 'bg-amber-500 shadow-[0_0_12px_rgba(245,158,11,0.5)] animate-pulse',
  idle: 'bg-gray-500',
};

const statusLabels: Record<PipelineAgent['status'], string> = {
  active: 'Active',
  processing: 'Processing',
  idle: 'Idle',
};

export default function PipelineFlow() {
  return (
    <div className="bg-gray-800/60 backdrop-blur rounded-xl border border-gray-700 p-5">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-sm font-semibold text-gray-300 uppercase tracking-wider">AI Pipeline</h3>
        <span className="flex items-center gap-1.5 text-xs text-emerald-400">
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
          Live 24/7
        </span>
      </div>
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        {pipelineAgents.map((agent, idx) => (
          <div key={agent.id} className="group relative">
            {/* Connector line (between cards) */}
            {idx < pipelineAgents.length - 1 && (
              <div className="hidden lg:block absolute -right-2.5 top-1/2 w-5 h-0.5 bg-gradient-to-r from-indigo-500/40 to-transparent z-0" />
            )}
            <div className="relative z-10 bg-gray-900/80 rounded-lg p-3 border border-gray-700/60 hover:border-indigo-500/40 transition-colors">
              <div className="flex items-center justify-between mb-2">
                <span className="text-lg">{agent.icon}</span>
                <span className={`w-2 h-2 rounded-full ${statusColors[agent.status]}`} />
              </div>
              <p className="text-xs font-medium text-gray-200 truncate">{agent.name}</p>
              <p className="text-[10px] text-gray-500 mt-0.5">{agent.description}</p>
              <div className="mt-2 flex items-center justify-between text-[10px]">
                <span className="text-gray-400">{agent.processed.toLocaleString()}</span>
                <span className="text-gray-500">{agent.rate}</span>
              </div>
              <div className="mt-1.5 w-full bg-gray-700 rounded-full h-1 overflow-hidden">
                <div
                  className="h-full rounded-full bg-gradient-to-r from-indigo-500 to-cyan-400 transition-all duration-700"
                  style={{ width: `${Math.min(100, (agent.processed / 3000) * 100)}%` }}
                />
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
