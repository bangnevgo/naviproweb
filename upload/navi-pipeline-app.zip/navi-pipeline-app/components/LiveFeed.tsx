'use client';

import { useState, useEffect, useRef } from 'react';
import type { LiveEvent } from '@/lib/demo-data';
import { generateLiveFeed } from '@/lib/demo-data';

export default function LiveFeed() {
  const [events, setEvents] = useState<LiveEvent[]>([]);
  const loaded = useRef(false);

  useEffect(() => {
    if (!loaded.current) {
      setEvents(generateLiveFeed(10));
      loaded.current = true;
    }

    const interval = setInterval(() => {
      setEvents(prev => {
        const newEvents = generateLiveFeed(1);
        return [newEvents[0], ...prev.slice(0, 14)];
      });
    }, 8000);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="bg-gray-800/60 backdrop-blur rounded-xl border border-gray-700 p-4">
      <div className="flex items-center justify-between mb-3">
        <h3 className="text-sm font-semibold text-gray-300 uppercase tracking-wider">Live Activity</h3>
        <span className="flex items-center gap-1.5 text-[10px] text-emerald-400">
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
          Live
        </span>
      </div>
      <div className="space-y-1.5 max-h-[320px] overflow-y-auto scrollbar-thin">
        {events.map((evt) => (
          <div key={evt.id} className="flex items-start gap-2 py-1.5 border-b border-gray-700/40 last:border-0 text-xs">
            <span className="text-gray-500 whitespace-nowrap mt-0.5">{evt.time}</span>
            <p className="text-gray-300 leading-tight">{evt.message}</p>
          </div>
        ))}
        {events.length === 0 && (
          <p className="text-gray-500 text-xs text-center py-4">Memuat data live...</p>
        )}
      </div>
    </div>
  );
}
