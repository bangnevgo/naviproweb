'use client';

import { useState } from 'react';
import type { Lead, LeadStatus } from '@/lib/demo-data';

const statusBadge: Record<LeadStatus, { label: string; class: string }> = {
  new: { label: 'New', class: 'bg-blue-500/20 text-blue-300 border-blue-500/30' },
  scored: { label: 'Scored', class: 'bg-purple-500/20 text-purple-300 border-purple-500/30' },
  messaged: { label: 'Contacted', class: 'bg-amber-500/20 text-amber-300 border-amber-500/30' },
  demo: { label: 'Demo', class: 'bg-indigo-500/20 text-indigo-300 border-indigo-500/30' },
  converted: { label: 'Converted', class: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30' },
};

interface Props {
  leads: Lead[];
}

export default function LeadTable({ leads }: Props) {
  const [sortKey, setSortKey] = useState<keyof Lead>('score');
  const [sortDir, setSortDir] = useState<'asc' | 'desc'>('desc');

  const sorted = [...leads].sort((a, b) => {
    const aVal = a[sortKey];
    const bVal = b[sortKey];
    if (typeof aVal === 'number' && typeof bVal === 'number') {
      return sortDir === 'desc' ? bVal - aVal : aVal - bVal;
    }
    return 0;
  });

  const toggleSort = (key: keyof Lead) => {
    if (sortKey === key) setSortDir(d => (d === 'desc' ? 'asc' : 'desc'));
    else { setSortKey(key); setSortDir('desc'); }
  };

  const SortIcon = ({ k }: { k: keyof Lead }) => (
    <span className="inline-block ml-1 text-gray-500 text-xs">
      {sortKey === k ? (sortDir === 'desc' ? '▼' : '▲') : '▽'}
    </span>
  );

  const scoreColor = (s: number) => {
    if (s >= 85) return 'text-emerald-400';
    if (s >= 70) return 'text-indigo-400';
    if (s >= 55) return 'text-amber-400';
    return 'text-gray-400';
  };

  return (
    <div className="overflow-x-auto">
      <table className="w-full text-sm">
        <thead>
          <tr className="border-b border-gray-700 text-gray-400 text-xs uppercase tracking-wider">
            <th className="text-left py-3 px-2 font-medium">Toko</th>
            <th className="text-left py-3 px-2 font-medium">Platform</th>
            <th className="text-left py-3 px-2 font-medium cursor-pointer select-none" onClick={() => toggleSort('score')}>
              Score<SortIcon k="score" />
            </th>
            <th className="text-left py-3 px-2 font-medium hidden md:table-cell">GMV</th>
            <th className="text-left py-3 px-2 font-medium hidden sm:table-cell">Pesanan</th>
            <th className="text-left py-3 px-2 font-medium">Status</th>
          </tr>
        </thead>
        <tbody>
          {sorted.map((lead) => (
            <tr key={lead.id} className="border-b border-gray-800/60 hover:bg-gray-800/40 transition-colors">
              <td className="py-2.5 px-2">
                <div>
                  <p className="text-gray-200 font-medium text-sm">{lead.name}</p>
                  <p className="text-gray-500 text-xs">{lead.store}</p>
                </div>
              </td>
              <td className="py-2.5 px-2">
                <span className="text-xs text-gray-400">{lead.platform}</span>
              </td>
              <td className={`py-2.5 px-2 font-bold text-sm ${scoreColor(lead.score)}`}>
                {lead.score}
              </td>
              <td className="py-2.5 px-2 text-gray-300 hidden md:table-cell">{lead.gmv}</td>
              <td className="py-2.5 px-2 text-gray-400 hidden sm:table-cell">{lead.orders.toLocaleString()}</td>
              <td className="py-2.5 px-2">
                <span className={`inline-block text-[10px] font-medium px-2 py-0.5 rounded-full border ${statusBadge[lead.status].class}`}>
                  {statusBadge[lead.status].label}
                </span>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
