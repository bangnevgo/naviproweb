'use client';

import { platformStats } from '@/lib/demo-data';

const cards = [
  { label: 'Total Leads', value: platformStats.totalLeads.toLocaleString(), change: '+12%', color: 'from-indigo-500 to-cyan-400' },
  { label: 'Today', value: platformStats.todayLeads.toString(), change: '+8%', color: 'from-emerald-500 to-teal-400' },
  { label: 'Reply Rate', value: `${platformStats.replyRate}%`, change: '+5%', color: 'from-purple-500 to-pink-400' },
  { label: 'Demo Booked', value: platformStats.demoBooked.toString(), change: '+34', color: 'from-amber-500 to-orange-400' },
  { label: 'Avg Score', value: platformStats.avgScore.toString(), change: '+4.2', color: 'from-rose-500 to-red-400' },
  { label: 'Conversion', value: `${platformStats.conversionRate}%`, change: '+3%', color: 'from-sky-500 to-blue-400' },
];

export default function AnalyticsCards() {
  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
      {cards.map((card) => (
        <div key={card.label} className="bg-gray-800/60 backdrop-blur rounded-xl border border-gray-700 p-4">
          <p className="text-[10px] uppercase tracking-wider text-gray-500 mb-1">{card.label}</p>
          <p className={`text-xl font-bold bg-gradient-to-r ${card.color} bg-clip-text text-transparent`}>
            {card.value}
          </p>
          <p className="text-[10px] text-emerald-400 mt-1">{card.change}</p>
        </div>
      ))}
    </div>
  );
}
